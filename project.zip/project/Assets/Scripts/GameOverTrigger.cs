using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOverTrigger : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            Debug.Log("Game Over! Игрок попал на опасный объект");
            SceneManager.LoadScene("GameOverScene"); // или перезапуск уровня
        }
    }
}