using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class HPManager : MonoBehaviour
{
    [Header("HP")]
    public int maxHP = 3;
    private int currentHP;

    [Header("UI Hearts")]
    public GameObject Hearticon;        // UI-префаб сердца (Image с RectTransform)
    public Transform HeartsContainer;    // Родитель в Canvas
    private readonly List<GameObject> hearts = new List<GameObject>();

    [Header("Invulnerability")]
    public float invulnerabilityTime = 1.0f;
    private bool isInvulnerable = false;
    private SpriteRenderer sr;

    private Vector3 checkpointPosition;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    void Start()
    {
        currentHP = maxHP;
         Debug.Log("Creating hearts, currentHP=" + currentHP);
        checkpointPosition = transform.position;
        CreateHeartsUI(); // создаем нужное количество сердец один раз
        UpdateHeartsUI(); // обновляем их видимость
    }

    public void TakeDamage()
    {
        if (isInvulnerable) return;

        currentHP = Mathf.Max(0, currentHP - 1);
        UpdateHeartsUI();

        if (currentHP == 0)
        {
            GameOver();
        }
        else
        {
            StartCoroutine(InvulnerabilityFlash());
        }
    }

    public void FallInPit()
    {
        currentHP = 0;
        UpdateHeartsUI();
        RespawnAtCheckpoint(fullRestore: true);
    }

    private void RespawnAtCheckpoint(bool fullRestore)
    {
        transform.position = checkpointPosition;

        var rb = GetComponent<Rigidbody2D>();
        if (rb) rb.linearVelocity = Vector2.zero;

        if (fullRestore)
        {
            currentHP = maxHP;
            UpdateHeartsUI();
        }
    }

    public void SetCheckpoint(Vector3 pos)
    {
        checkpointPosition = pos;
    }

    // Создаем сердца один раз при старте
    private void CreateHeartsUI()
    {
        if (!HeartsContainer || !Hearticon) return;

        for (int i = 0; i < maxHP; i++)
        {
            var heart = Instantiate(Hearticon, HeartsContainer);
            var rt = heart.GetComponent<RectTransform>();
            if (rt != null)
                rt.sizeDelta = new Vector2(32, 32);
            hearts.Add(heart);
        }
    }

    // Просто включаем/выключаем сердца в зависимости от currentHP
    private void UpdateHeartsUI()
    {
        for (int i = 0; i < hearts.Count; i++)
        {
            hearts[i].SetActive(i < currentHP);
        }
    }

    private IEnumerator InvulnerabilityFlash()
    {
        isInvulnerable = true;
        float t = 0f;

        while (t < invulnerabilityTime)
        {
            if (sr) sr.enabled = !sr.enabled;
            yield return new WaitForSeconds(0.1f);
            t += 0.1f;
        }

        if (sr) sr.enabled = true;
        isInvulnerable = false;
    }
    private void GameOver()
    {
        Debug.Log("Game Over! Жизни закончились.");
        SceneManager.LoadScene("GameOverScene");
    }
}