using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;

public class PauseMenu : MonoBehaviour
{
    public GameObject pausePanel;
    public AudioMixer musicMixer;
    public AudioMixer sfxMixer;
    public Slider musicSlider;
    public Slider sfxSlider;

    [Header("UI Scale")]
    public float uiScale = 1.4f; // сделает меню больше

    private bool isPaused;

    void Start()
    {
        if (pausePanel)
        {
            pausePanel.SetActive(false);
            // увеличим визуально меню
            pausePanel.transform.localScale = Vector3.one * uiScale;
        }

        if (musicMixer && musicMixer.GetFloat("MusicVolume", out float musicVol))
            musicSlider.value = Mathf.InverseLerp(-80f, 0f, musicVol);

        if (sfxMixer && sfxMixer.GetFloat("SFXVolume", out float sfxVol))
            sfxSlider.value = Mathf.InverseLerp(-80f, 0f, sfxVol);

        musicSlider.onValueChanged.AddListener(v => musicMixer.SetFloat("MusicVolume", Mathf.Lerp(-80f, 0f, v)));
        sfxSlider.onValueChanged.AddListener(v => sfxMixer.SetFloat("SFXVolume", Mathf.Lerp(-80f, 0f, v)));
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
            TogglePause();
    }

    public void TogglePause()
    {
        isPaused = !isPaused;
        if (pausePanel) pausePanel.SetActive(isPaused);
        Time.timeScale = isPaused ? 0f : 1f;
    }

    public void ResumeGame() => TogglePause();

    public void ExitGame()
    {
        Time.timeScale = 1f;
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;   // работает в редакторе
#else
        Application.Quit();                                // работает в билде
#endif
    }
}