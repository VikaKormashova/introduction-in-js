using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class Projectile : MonoBehaviour
{
    public float speed = 12f;
    public float lifeTime = 3f;
    public string enemyTag = "Enemy";

    private Rigidbody2D rb;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    public void Launch(float dir)
    {
        // dir должен быть +1 (вправо) или -1 (влево)
        rb.linearVelocity = new Vector2(dir * speed, 0f);
        // Поворачиваем спрайт по направлению
        var ls = transform.localScale;
        transform.localScale = new Vector3(Mathf.Abs(ls.x) * Mathf.Sign(dir), ls.y, ls.z);

        Destroy(gameObject, lifeTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // игнорируем игрока и чекпоинты
        if (other.CompareTag("Player") || other.CompareTag("Player"))
            return;

        if (other.CompareTag(enemyTag))
        {
            Destroy(other.gameObject);
            Destroy(gameObject);
        }
        else
        {
            // при попадании во что-то ещё — просто уничтожаемся (по желанию)
            Destroy(gameObject);
        }
    }
}