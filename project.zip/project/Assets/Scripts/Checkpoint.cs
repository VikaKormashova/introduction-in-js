using UnityEngine;

public class Checkpoint : MonoBehaviour
{
    [Tooltip("Опционально: визуальный индикатор активируется при касании")]
    public GameObject activatedFx;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        var hp = other.GetComponent<HPManager>();
        if (hp != null) hp.SetCheckpoint(transform.position);

        if (activatedFx) activatedFx.SetActive(true);
    }
}