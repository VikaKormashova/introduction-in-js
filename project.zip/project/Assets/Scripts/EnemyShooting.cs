using UnityEngine;

public class EnemyShooting : MonoBehaviour
{
    [Header("Shooting Settings")]
    public GameObject projectilePrefab;
    public Transform firePoint;
    public float shootInterval = 2f;
    private float timer;

    void Update()
    {
        timer += Time.deltaTime;

        if (timer >= shootInterval)
        {
            Shoot();
            timer = 0f;
        }
    }

    void Shoot()
    {
        if (!projectilePrefab || !firePoint) return;

        GameObject bullet = Instantiate(projectilePrefab, firePoint.position, Quaternion.identity);

        var proj = bullet.GetComponent<EnemyProjectile>();
        if (proj != null)
        {
            float dir = transform.localScale.x > 0 ? 1f : -1f;
            proj.Launch(dir);
        }
    }
}