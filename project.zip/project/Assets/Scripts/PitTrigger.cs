using UnityEngine;
using UnityEngine.SceneManagement;

public class PitTrigger : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            Debug.Log("Игрок упал в пропасть! Game Over");
            SceneManager.LoadScene("GameOverScene");
        }
    }
}
