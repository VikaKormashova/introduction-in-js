using UnityEngine;

public class PlayerShooting : MonoBehaviour
{
    public Projectile projectilePrefab;
    public Transform firePoint;   // точка, откуда вылетает пуля
    public float fireRate = 0.25f;

    private float nextFireTime;

    void Update()
    {
        // Проверка на нажатие кнопки и время следующего выстрела
        if (Input.GetKey(KeyCode.Z) && Time.time >= nextFireTime)
        {
            nextFireTime = Time.time + fireRate;

            // Направление пули в зависимости от того, куда смотрит игрок
            float dir = transform.localScale.x >= 0 ? 1f : -1f;

            // Создаём пулю на позиции firePoint
            Projectile p = Instantiate(projectilePrefab, firePoint.position, Quaternion.identity);

            // Запускаем пулю в нужном направлении
            p.Launch(dir);

            // Поворачиваем пулю визуально, чтобы смотрела в сторону движения
            Vector3 scale = p.transform.localScale;
            p.transform.localScale = new Vector3(Mathf.Abs(scale.x) * Mathf.Sign(dir), scale.y, scale.z);
        }
    }
}