using UnityEngine;

public class DamageDealer : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            var hp = other.GetComponent<HPManager>();
            if (hp != null) hp.TakeDamage();
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.collider.CompareTag("Player"))
        {
            var hp = other.collider.GetComponent<HPManager>();
            if (hp != null) hp.TakeDamage();
        }
    }
}