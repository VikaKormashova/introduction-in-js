using UnityEngine;

public class SceneTrigger2D : MonoBehaviour
{
    [SerializeField] private string sceneToLoad;

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log($"OnTriggerEnter2D сработал для {other.name} (тег={other.tag})");

        if (other.CompareTag("Player"))
        {
            if (SceneController.Instance != null)
            {
                Debug.Log("Загрузка сцены: " + sceneToLoad);
                SceneController.Instance.LoadScene(sceneToLoad);
            }
            else
            {
                Debug.LogError("SceneController.Instance == null!");
            }
        }
    }
}
