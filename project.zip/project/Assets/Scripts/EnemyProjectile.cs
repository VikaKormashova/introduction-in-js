using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class EnemyProjectile : MonoBehaviour
{
    public float speed = 2f;       // скорость пули
    public float lifeTime = 20f;   // время жизни

    private Rigidbody2D rb;

    public void Launch(float dir)
    {
        rb = GetComponent<Rigidbody2D>();

        // ставим направление только один раз
        rb.linearVelocity = new Vector2(dir * speed, 0f);

        // разворачиваем визуально
        var ls = transform.localScale;
        transform.localScale = new Vector3(Mathf.Abs(ls.x) * Mathf.Sign(dir), ls.y, ls.z);

        // уничтожаем пулю через lifeTime (она не исчезнет раньше сама по себе)
        Destroy(gameObject, lifeTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
{
    if (other.CompareTag("Player"))
    {
        var hp = other.GetComponent<HPManager>();
        if (hp != null) hp.TakeDamage();
        Destroy(gameObject);
        return;
    }

    // Игнорируем врага и чекпоинт
    if (other.CompareTag("Enemy"))
        return;

    // Уничтожаем только если реально врезались в землю
    if (other.CompareTag("Ground"))
        Destroy(gameObject);
}

}
