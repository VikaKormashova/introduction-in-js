using UnityEngine;
using TMPro;

public class CoinTextInitializer : MonoBehaviour
{
    public TMP_Text coinText;

    void Start()
    {
        if (CoinManager.Instance != null)
        {
            CoinManager.Instance.SetCoinText(coinText);
        }
    }
}