using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target; // ссылка на игрока
    public float smoothSpeed = 0.125f; // скорость сглаживания
    public Vector3 offset; // смещение камеры относительно игрока

    void LateUpdate()
    {
        if(target == null) return;

        Vector3 desiredPosition = target.position + offset;
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        transform.position = smoothedPosition;
    }
}
