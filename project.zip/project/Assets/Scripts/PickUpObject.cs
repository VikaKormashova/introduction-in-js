using UnityEngine;
using TMPro; 

public class PickupObject : MonoBehaviour
{
    public AudioClip pickupSound;
    public AudioSource sfxSource;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;

        // Воспроизводим звук
        if (pickupSound && sfxSource)
            sfxSource.PlayOneShot(pickupSound);

        // Увеличиваем счетчик монет
        CoinManager.Instance.AddCoin(); // 

        // Удаляем монету
        Destroy(gameObject);
    }
}