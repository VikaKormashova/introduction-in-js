using UnityEngine;

public class EnemyPatrol : MonoBehaviour
{
    public Transform pointA;
    public Transform pointB;
    public float speed = 2f;

    private Transform target;

    void Start()
    {
        target = pointB; // идём сначала к B
    }

    void Update()
    {
        // Движение к текущей цели
        transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

        // Если дошли почти до точки — меняем направление
        if (Vector2.Distance(transform.position, target.position) < 0.1f)
        {
            target = (target == pointA) ? pointB : pointA;

            // Разворот по оси X (чтобы смотрел в сторону движения)
            Vector3 scale = transform.localScale;
            scale.x *= -1;
            transform.localScale = scale;
        }
    }
}