using UnityEngine;

public class DeathZone : MonoBehaviour
{
    public AudioClip deathSound;
    public AudioSource sfxSource;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if (deathSound && sfxSource) sfxSource.PlayOneShot(deathSound);
            var hp = other.GetComponent<HPManager>();
            if (hp != null) hp.FallInPit();
        }
    }
}