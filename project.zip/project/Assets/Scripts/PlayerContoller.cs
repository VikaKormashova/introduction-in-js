using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 5f;
    public float jumpForce = 12f;

    [Header("Ground Check")]
    public LayerMask groundLayer;
    public Transform groundCheck;
    public float groundCheckRadius = 0.2f;

    [Header("SFX")]
    public AudioSource sfxSource;
    public AudioClip jumpSound;

    private Rigidbody2D rb;
    private Animator anim;
    private bool isGrounded;

    private Vector3 originalScale; // сохраняем первоначальный масштаб

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        originalScale = transform.localScale;
    }

    void Update()
    {
        float move = Input.GetAxisRaw("Horizontal");
        rb.linearVelocity = new Vector2(move * moveSpeed, rb.linearVelocity.y);

        // Отражаем только знак по X, не меняя размер
        if (move > 0)
            transform.localScale = new Vector3(Mathf.Abs(originalScale.x), originalScale.y, originalScale.z);
        else if (move < 0)
            transform.localScale = new Vector3(-Mathf.Abs(originalScale.x), originalScale.y, originalScale.z);

        // Проверка земли
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            if (jumpSound && sfxSource) sfxSource.PlayOneShot(jumpSound);
        }

        // Анимации (если используешь стейт-машину с int "State")
        if (!isGrounded) anim.SetInteger("State", 2);
        else if (move != 0) anim.SetInteger("State", 1);
        else anim.SetInteger("State", 0);
    }
}