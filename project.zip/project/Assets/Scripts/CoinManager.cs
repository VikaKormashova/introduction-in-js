using UnityEngine;
using TMPro; 

public class CoinManager : MonoBehaviour
{
    public static CoinManager Instance; // глобальный доступ
    public int coinCount = 0;           // текущее количество монет
    public TMP_Text coinText;           // ссылка на текст в Canvas

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // сохраняем CoinManager между сценами
        }
        else
        {
            Destroy(gameObject); // удаляем дубликаты
        }
    }

    // Метод для добавления монеты
    public void AddCoin()
    {
        coinCount++;
        UpdateUI();
    }

    // Метод обновления текста на UI
    private void UpdateUI()
    {
        if (coinText != null)
            coinText.text = "Coins: " + coinCount;
    }

    // Метод для подключения текста на новой сцене
    public void SetCoinText(TMP_Text newText)
    {
        coinText = newText;
        UpdateUI(); // сразу обновляем текст
    }
}